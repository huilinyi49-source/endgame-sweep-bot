from datetime import datetime

try:
    from zoneinfo import ZoneInfo
except ImportError:
    from backports.zoneinfo import ZoneInfo
import pytz

def is_weekend_in_et() -> bool:
    et_now = datetime.now(ZoneInfo("America/New_York"))
    return et_now.weekday() >= 5   # 5=周六, 6=周日

def get_et_timestamp_label() -> str:
    now_et = datetime.now(ZoneInfo("America/New_York"))

    month = now_et.strftime("%B").lower()      # february
    day = now_et.day                           # 4
    hour_12 = now_et.strftime("%I").lstrip("0")  # 08 -> 8
    am_pm = now_et.strftime("%p").lower()      # AM -> am

    return f"{month}-{day}-{hour_12}{am_pm}-et"

def get_market_start() -> int:
    now = datetime.now()
    hour_start = now.replace(minute=0, second=0, microsecond=0)
    return int(hour_start.timestamp())


def get_est_floor_quarter_timestamp():
    """
    按美东时间，通过 分钟//15 取整（往前数），秒数置零，返回对应时间戳
    """
    est_tz = pytz.timezone('America/New_York')

    now_est = datetime.now(est_tz)
    current_minute = now_est.minute

    # 直接整除计算
    target_minute = (current_minute // 15) * 15

    target_time = now_est.replace(
        minute=target_minute,
        second=0,
        microsecond=0
    )

    target_utc = target_time.astimezone(pytz.UTC)
    timestamp = int(target_utc.timestamp())

    return timestamp


def is_danger_time(now: datetime | None = None) -> bool:
    """
    判断是否处于美股正常交易时段（ET 工作日 9:30–16:00）

    - 可传入 datetime 用于测试
    - 不传则使用当前时间
    - 自动转换为美东时间
    """

    ET = ZoneInfo("America/New_York")

    # 获取当前时间（转换为 ET）
    if now is None:
        now = datetime.now(ET)
    else:
        if now.tzinfo is None:
            # 如果是 naive datetime，假设它本身就是 ET
            now = now.replace(tzinfo=ET)
        else:
            now = now.astimezone(ET)

    # 周末休市
    if now.weekday() >= 5:
        return False

    market_open = time(9, 30)
    market_close = time(16, 0)

    return market_open <= now.time() < market_close
