"""
扫polymarket上一小时的比特币的涨跌预测
执行条件:
1.交易时间段:美东时间周末时间段星期六0:00到星期日23:59
2.该交易盘剩余时间需要在1800s到60s之间
3.比特币涨跌绝对值需要达到150
4.根据比特币的开,高,低,收把K线分成三端,中间那段的占比必须大于0.3
5.代币需要大于或者等于0.95
6.买入的代币份额为5.2
7.买入之后如果比特币的涨跌绝对值达到15以0.45的价格卖出购入的所有代币
8.市场结束之后判断市场结果记入在案
"""
import asyncio
import logging
from datetime import datetime
from typing import Optional, Tuple

import httpx
import time
from utils import is_weekend_in_et, get_et_timestamp_label, get_market_start,get_est_floor_quarter_timestamp,is_danger_time
from trading_client import get_client,place_order,place_market_order,get_positions,get_position_by_token_id
from market_lookup import fetch_market_from_slug
from config import load_settings
from py_clob_client.clob_types import BookParams

logging.basicConfig(
    level=logging.WARNING,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
logging.getLogger("httpx").setLevel(logging.WARNING)


def find_current_crypto_15M_market() -> str:
    time_label = get_est_floor_quarter_timestamp()
    return f'btc-updown-15m-{time_label}'


class EndgameSweepBot:
    def __init__(self, settings):
        self.settings = settings
        self.client = get_client(settings)
        self.initialize_market()


    def initialize_market(self):
        market_slug = find_current_crypto_15M_market()
        market_info = fetch_market_from_slug(market_slug)
        self.yes_token_id = market_info["yes_token_id"]
        self.no_token_id = market_info["no_token_id"]
        market_start = get_est_floor_quarter_timestamp()
        self.market_end_timestamp = market_start + 900 if market_start else None
        self.market_slug = market_slug
        logger.info(f"市场： | YES: {self.yes_token_id} | NO: {self.no_token_id}")
        self.current_market_trades = 0
        self.opportunities_found = 0
        self.trades_executed = 0
        self.token_id_bought = None
        self.shares = 0
        self.max_token_price = 0

    def get_time_remaining(self) -> str:
        if not self.market_end_timestamp:
            return "Unknown"
        now = int(datetime.now().timestamp())
        remaining = self.market_end_timestamp - now
        self.remaining = remaining
        if remaining <= 0:
            return "CLOSED"
        minutes, seconds = divmod(remaining, 60)
        return f"{minutes}m {seconds}s"

    async def get_current_tokens_prices(self) -> Tuple[Optional[float], Optional[float]]:
        try:
            params = [BookParams(token_id=self.yes_token_id), BookParams(token_id=self.no_token_id)]
            # 非异步SDK用 to_thread
            prices_response = await asyncio.to_thread(self.client.get_last_trades_prices, params)
            price_up = price_down = None
            for item in prices_response:
                if item.get("token_id") == self.yes_token_id:
                    price_up = float(item.get("price", 0))
                elif item.get("token_id") == self.no_token_id:
                    price_down = float(item.get("price", 0))
            self.max_token_price = max(price_up, price_down)
            return price_up, price_down
        except Exception as e:
            logger.error(f"获取代币价格失败: {e}")
            return None, None
    def get_bought_token_price(self) -> Tuple[Optional[float]]:
        try:
            params = [
                BookParams(token_id=self.token_id_bought),
                BookParams(token_id=self.token_id_bought)
            ]
            prices_response = self.client.get_last_trades_prices(params=params)
            price = 0
            for item in prices_response:
                if item.get("token_id") == self.token_id_bought:
                    price = float(item.get("price", 0))
                elif item.get("token_id") == self.token_id_bought:
                    price = float(item.get("price", 0))

            return price
        except Exception as e:
            logger.error(f"获取价格时出错: {e}")
            return None
    async def get_binance_btc_15min_price(self) -> Tuple[float, float, float, float]:
        url = "https://api.binance.com/api/v3/klines"
        params = {"symbol": "BTCUSDT", "interval": "15m", "limit": 1}
        try:
            async with httpx.AsyncClient(timeout=20) as client:
                resp = await client.get(url, params=params)
                resp.raise_for_status()
                data = resp.json()
            last_kline = data[-1]
            return float(last_kline[1]), float(last_kline[2]), float(last_kline[3]), float(last_kline[4])
        except httpx.HTTPError as e:
            logger.error(f"获取BTC K线失败: {e}")
            return 0.0, 0.0, 0.0, 0.0

    def check_token_price(self, price_up: float, price_down: float) -> bool:
        if price_up is None or price_down is None:
            return False
        total_cost = price_up + price_down
        self.total_cost = total_cost
        if total_cost > self.settings.market_overround_limit:
            return False
        if price_up < self.settings.token_target_price and price_down < self.settings.token_target_price:
            return False
        return True

    def check_btc_price(self, open_price, high_price, low_price, close_price) -> bool:
        all_section = high_price - low_price
        diff = close_price - open_price
        self.diff = diff
        middle_section = abs(open_price - close_price)
        self.middle_section = middle_section
        if middle_section == 0 or all_section == 0:
            return False
        self.middle_ratio = middle_section / all_section
        if middle_section < self.settings.btc_price_change_threshold:
            return False
        if self.middle_ratio < self.settings.middle_section_limit:
            return False
        return True

    async def check_sweep(self) -> Optional[dict]:
        # 并行启动两个任务
        price_task = asyncio.create_task(self.get_current_tokens_prices())
        btc_task = asyncio.create_task(self.get_binance_btc_15min_price())

        # 先等待代币价格
        price_up, price_down = await price_task
        if price_up is None or price_down is None:
            return None
        self.last_price_info = (price_up, price_down)

        # BTC 数据异步更新缓存（不阻塞主逻辑）
        async def update_btc_cache():
            try:
                open_price, high_price, low_price, close_price = await btc_task
                if all([open_price, high_price, low_price, close_price]):
                    self.btc_price = (open_price, high_price, low_price, close_price)
            except Exception as e:
                logger.error(f"更新BTC缓存失败: {e}")

        asyncio.create_task(update_btc_cache())

        # 使用上一次缓存的BTC数据（第一次扫描可能为空）
        if hasattr(self, "btc_price") and self.btc_price:
            open_price, high_price, low_price, close_price = self.btc_price
        else:
            # 第一次没有缓存，则直接用代币价格返回
            return None

        # 检查代币价格和BTC涨跌
        token_ok = self.check_token_price(price_up, price_down)
        btc_ok = self.check_btc_price(open_price, high_price, low_price, close_price)


        # 返回机会
        if token_ok and btc_ok:
            price = price_up if self.diff > 0 else price_down
            token_id = self.yes_token_id if self.diff > 0 else self.no_token_id
            return {
                "price": price,
                "order_size": self.settings.token_order_size,
                "token_id": token_id,
                "timestamp": datetime.now().isoformat()
            }

        return None

    def execute_sweep(self, opportunity: dict):
        self.opportunities_found += 1
        logger.info(f"发现机会: {opportunity}")
        # if is_weekend_in_et():
        #     logger.info("非美东周末，不执行交易")
        #     return

        # 剩余时间限制
        now = int(datetime.now().timestamp())
        remaining = self.market_end_timestamp - now
        if is_danger_time():
            return
        if remaining < self.settings.min_minutes_to_expiry_for_entry or remaining > self.settings.max_minutes_to_expiry_for_entry:
            return

        if self.settings.per_market_max_trade > 0 and self.current_market_trades >= self.settings.per_market_max_trade:
            return
        try:
            # 执行订单
            logger.info("\n📤 正在扫尾盘执行订单...")

            # 使用套利机会中的精确价格
            price = opportunity['price']
            token_id = opportunity['token_id']

            # 正确的传参方式：使用字典的[key]访问值
            # result = place_order(
            #     self.settings,
            #     side="BUY",  # 用[]访问字典值，而非.
            #     token_id=token_id,
            #     price=price-0.01,
            #     size=self.settings.token_order_size,
            #     tif="GTC"
            # )

            result = place_market_order(
                self.settings,
                side="BUY",
                token_id=token_id,
                amount=self.settings.token_order_size
            )
            # 检查结果
            if isinstance(result, dict) and "error" in result:
                logger.error(f"❌ 订单错误: {result['error']}")
                raise RuntimeError(f"Order failed: {result}")
            else:
                logger.info(
                    f"✅ 订单已提交:"
                )
                self.trades_executed += 1
                self.current_market_trades += 1
                self.token_id_bought = token_id

        except Exception as e:
            logger.error(f"\n❌ 执行扫尾盘时出错: {e}")
            logger.error("❌ 订单未执行 - 未更新跟踪信息")
        # 执行交易逻辑（此处可调用 place_order 或 place_market_order）
   
    def show_current_positions(self):
        """显示 UP 和 DOWN 代币的当前股份持仓。"""
        try:
            positions = get_positions(self.settings, [self.token_id_bought])
            shares = positions.get(self.token_id_bought, {}).get("size", 0)
            if not shares:
                self.shares = 0.0
            else:
                self.shares = shares
            
            logger.info("-" * 70)
            logger.info(f"   股份:   {self.shares:.2f}")
            logger.info("-" * 70)
            
        except Exception as e:
            logger.warning(f"无法获取持仓: {e}")

    def check_order(self):
        logger.info("开始检测卖单数据，防止突发情况")
        if self.shares <= self.settings.token_order_size-0.01:
            try:
                self.show_current_positions()
            except Exception as e:
                logger.error(f"\n❌ 检查持仓出错: {e}")
        price = self.get_bought_token_price()
        if price is None :
            return
        if(price <= 0.55):
            try:
                # 执行订单
                logger.info("\n📤 正在执行止损订单...")
                # 正确的传参方式：使用字典的[key]访问值
                result = place_order(
                    self.settings,
                    side="SELL",  # 用[]访问字典值，而非.
                    token_id=self.token_id_bought,
                    price=0.45,
                    size=self.shares,
                    tif="GTC"
                )
                # 检查结果
                if isinstance(result, dict) and "error" in result:
                    logger.error(f"❌ 订单错误: {result['error']}")
                    raise RuntimeError(f"Order failed: {result}")
                else:
                    logger.info(
                        f"✅ 订单已提交:"
                    )
                    
            except Exception as e:
                logger.error(f"\n❌ 执行止损订单出错: {e}")
                logger.error("❌ 执行止损订单未执行 - 未更新跟踪信息")
        else:
            logger.info("\n订单安全...")
    async def countdown_sleep(self, total_seconds):
        """带实时倒计时的异步休眠函数"""
        remaining = total_seconds
        while remaining > 0:
            # 打印倒计时信息（可根据需要调整输出格式，比如加颜色、进度条等）
            print(f"\r等待中，剩余 {remaining} 秒...", end="", flush=True)
            await asyncio.sleep(1)  # 每秒更新一次
            remaining -= 1
        # 倒计时结束后换行，清理输出
        print("\n等待结束，继续执行后续操作！")

    async def main_logic(self):
        # 修正 elif 语法，确定休眠时长
        if self.max_token_price < 0.8 and self.remaining > 450:
            interval_seconds = 150
        elif self.max_token_price < 0.8 and self.remaining < 450:
            interval_seconds = 90
        elif self.max_token_price < 0.9:
            interval_seconds = 30
        else:
            # 补充默认值，避免变量未定义报错
            interval_seconds = 5  

        # 执行带倒计时的休眠
        print(f"即将休眠 {interval_seconds} 秒，开始倒计时：")
        await self.countdown_sleep(interval_seconds)
    async def run_once(self) -> bool:
        if self.get_time_remaining() == "CLOSED":
            return False
        if self.settings.per_market_max_trade > 0 and self.current_market_trades >= self.settings.per_market_max_trade:
            # self.check_order()
            return

        opportunity = await self.check_sweep()

        # 打印调试信息
        if hasattr(self, "last_price_info") and hasattr(self, "diff") and hasattr(self, "middle_section") and hasattr(self, "middle_ratio") and hasattr(self, "total_cost"):
            price_up, price_down = self.last_price_info
            print("="*50)
            print(f"📊 代币价格: YES={price_up:.4f}, NO={price_down:.4f}")
            print(f"💰 代币总价差: {self.total_cost:.4f}")
            print(f"📈 BTC 涨跌幅度: {self.diff:.4f}")
            print(f"🔹 K线中间段幅值: {self.middle_section:.4f} | 占比: {self.middle_ratio:.4f}")
            print(f"⏱ 剩余时间: {self.get_time_remaining()}")
            print("="*50)

        if opportunity:
            self.execute_sweep(opportunity)
            return True
        return False

    async def monitor(self, interval_seconds: int = 5):
        logger.info(f"🚀 比特币扫尾盘机器人启动 - 市场: {self.market_slug}")
        scan_count = 0
        try:
            while True:
                scan_count += 1
                if self.get_time_remaining() == "CLOSED":
                    await self.countdown_sleep(30)
                    new_market_slug = find_current_crypto_15M_market()
                    if new_market_slug != self.market_slug:
                        self.initialize_market()
                        scan_count = 0
                        continue
                    await asyncio.sleep(5)
                    continue

                await self.run_once()
                logger.info(f"扫描次数: {scan_count} | 机会: {self.opportunities_found} | 交易: {self.trades_executed}")
                if not self.token_id_bought:
                    await self.main_logic()
                else:
                    await self.countdown_sleep(5)
        except KeyboardInterrupt:
            logger.info("机器人停止")
            logger.info(f"总扫描次数: {scan_count} | 机会: {self.opportunities_found} | 交易: {self.trades_executed}")


if __name__ == "__main__":
    settings = load_settings()

    settings.btc_price_change_threshold = 50
    settings.max_minutes_to_expiry_for_entry = 450
    settings.min_minutes_to_expiry_for_entry = 30
    settings.token_target_price = 0.96
    settings.token_order_size = 1
    settings.stop_loss_btc_price_change = 10
    settings.stop_loss_token_price = 0.45
    settings.per_market_max_trade = 1
    settings.market_overround_limit = 1.03
    settings.middle_section_limit = 0.5

    print(settings)

    bot = EndgameSweepBot(settings)
    asyncio.run(bot.monitor(interval_seconds=0))