import os
from dataclasses import dataclass

from dotenv import load_dotenv

# 如果存在，从项目根目录加载 .env 文件；覆盖现有环境变量以优先使用 .env 编辑
load_dotenv(override=True)


@dataclass
class Settings:
    api_key: str = os.getenv("POLYMARKET_API_KEY", "")
    api_secret: str = os.getenv("POLYMARKET_API_SECRET", "")
    api_passphrase: str = os.getenv("POLYMARKET_API_PASSPHRASE", "")
    private_key: str = os.getenv("POLYMARKET_PRIVATE_KEY", "")
    signature_type: int = int(os.getenv("POLYMARKET_SIGNATURE_TYPE", "1"))
    funder: str = os.getenv("POLYMARKET_FUNDER", "")
    btc_price_change_threshold:float = float(os.getenv("btc_price_change_threshold","200"))
    eth_price_change_threshold:float = float(os.getenv("btc_price_change_threshold","10"))
    max_minutes_to_expiry_for_entry:float = float(os.getenv("max_minutes_to_expiry_for_entry","1800"))
    min_minutes_to_expiry_for_entry:float = float(os.getenv("min_minutes_to_expiry_for_entry","60"))
    token_target_price:float = float(os.getenv("token_target_price","0.96"))
    token_order_size:float = float(os.getenv("token_order_size","1"))
    stop_loss_btc_price_change:float = float(os.getenv("stop_loss_btc_price_change","10"))
    stop_loss_token_price:float = float(os.getenv("stop_loss_token_price","0.45"))
    per_market_max_trade:int = int(os.getenv("per_market_max_trade","1"))
    market_overround_limit:float = float(os.getenv("market_overround_limit", "1.03"))
    middle_section_limit:float = float(os.getenv("middle_section_limit","0.333"))


def load_settings() -> Settings:
    return Settings()

