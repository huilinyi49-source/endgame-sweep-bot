import asyncio
import time
import sys
import logging
from auto_redeem import AutoRedeem  # 导入核心业务类
from config import load_settings    # 导入配置加载函数
from trading_client import get_balance,get_positions
from config import load_settings

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),  # 输出到控制台
        logging.FileHandler("redeem_log.log", encoding="utf-8")  # 同时写入日志文件
    ]
)
logger = logging.getLogger(__name__)
settings = load_settings()

# 执行间隔配置（8分钟 = 480秒）
EXECUTE_INTERVAL = 3 * 60

async def run_single_redeem_task():
    """执行单次赎回任务，包含完整异常处理"""
    try:
        logger.info("\n" + "="*60)
        logger.info(f"📌 开始执行赎回任务 - {time.strftime('%Y-%m-%d %H:%M:%S')}")
        logger.info("="*60)
        
        settings = load_settings()
        auto_redeem = AutoRedeem(settings)
        await auto_redeem.execute_redeem()
        
    except Exception as e:
        logger.error(
            f"❌ 单次赎回任务执行失败: {type(e).__name__} - {str(e)}",
            exc_info=True  # 打印完整异常堆栈
        )
    finally:
        logger.info("="*60)
        logger.info(f"🔚 本次赎回任务执行结束 - {time.strftime('%Y-%m-%d %H:%M:%S')}")
        logger.info("="*60)

async def countdown(seconds):
    """实时倒计时函数，动态刷新控制台输出"""
    for remaining in range(seconds, 0, -1):
        # 计算时分秒格式
        mins, secs = divmod(remaining, 60)
        time_format = f"{mins:02d}:{secs:02d}"
        # 动态刷新一行输出（\r 表示回到行首，\033[K 清空当前行）
        sys.stdout.write(f"\r⏳ 下次执行剩余时间: {time_format} ")
        sys.stdout.flush()
        await asyncio.sleep(1)  # 每秒递减1秒
    # 倒计时结束后清空该行
    sys.stdout.write("\r" + " " * 40 + "\r")
    sys.stdout.flush()

async def main_scheduler():
    """定时调度主函数：每8分钟执行一次 + 实时倒计时"""
    logger.info(f"\n🚀 自动赎回程序启动成功！")
    logger.info(f"📅 启动时间: {time.strftime('%Y-%m-%d %H:%M:%S')}")
    logger.info(f"⏰ 执行间隔: {EXECUTE_INTERVAL // 60} 分钟 ({EXECUTE_INTERVAL} 秒)")
    logger.info(f"🔍 按 Ctrl+C 可终止程序\n")


    
    while True:
        # 执行单次赎回任务
        await run_single_redeem_task()
        
        # 启动实时倒计时
        logger.info(f"\n⌛ 开始等待下一次执行...")
        await countdown(EXECUTE_INTERVAL)
        logger.info(f"🔄 倒计时结束，准备执行下一次任务！")


if __name__ == "__main__":

    try:
        asyncio.run(main_scheduler())
    except KeyboardInterrupt:
        # 处理用户手动终止，清理控制台输出
        sys.stdout.write("\r" + " " * 40 + "\r")
        sys.stdout.flush()
        logger.info(f"\n🛑 程序被用户手动终止 - {time.strftime('%Y-%m-%d %H:%M:%S')}")
    except Exception as e:
        logger.critical(
            f"\n💥 主程序发生致命错误: {type(e).__name__} - {str(e)}",
            exc_info=True
        )