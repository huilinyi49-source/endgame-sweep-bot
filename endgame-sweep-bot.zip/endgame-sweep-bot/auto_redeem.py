# -*- coding = utf-8 -*-
# @Time: 2025-12-27 17:01:20
# @Author: PinBar
# @Site:
# @File: example_redeem.py
# @Software: PyCharm

# =========================
# ENV
# =========================
# POLYMARKET_PRIVATE_KEY
# POLYMARKET_FUNDER
# POLYMARKET_API_KEY
# POLYMARKET_API_SECRET
# POLYMARKET_API_PASSPHRASE

import os
import logging
import dotenv
import asyncio
import warnings
import httpx

from py_builder_relayer_client.client import RelayClient
from py_builder_signing_sdk.config import BuilderConfig
from py_builder_signing_sdk.sdk_types import BuilderApiKeyCreds
from py_clob_client.client import ClobClient
from poly_web3 import RELAYER_URL, PolyWeb3Service
from config import load_settings

# =========================
# 初始化
# =========================
dotenv.load_dotenv()


logging.basicConfig(
    level=logging.WARNING,
    format="%(asctime)s - %(levelname)s - %(message)s",
)

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


class AutoRedeem:
    def __init__(self, settings):
        self.settings = settings

    # =========================
    # 异步获取可赎回 condition
    # =========================
    async def get_redeemable_condition_ids(self):
        user_address = self.settings.funder
        if not user_address:
            logger.error("未配置 POLYMARKET_FUNDER 地址")
            return []

        api_url = (
            f"https://data-api.polymarket.com/positions?user={user_address}"
        )

        try:
            async with httpx.AsyncClient(timeout=10) as client:
                response = await client.get(api_url)
                response.raise_for_status()
                positions = response.json()

            condition_ids = set()

            for pos in positions or []:
                if float(pos.get("size", 0)) <= 0:
                    continue
                if not pos.get("redeemable", False):
                    continue

                cid = pos.get("conditionId")
                if cid:
                    condition_ids.add(cid)

            return list(condition_ids)

        except Exception as e:
            logger.error(f"获取持仓时出错: {e}")
            return []

    # =========================
    # 同步 redeem（原逻辑）
    # =========================
    def _redeem_on_chain_sync(self, condition_ids):
        host = "https://clob.polymarket.com"
        chain_id = 137

        client = ClobClient(
            host,
            key=os.getenv("POLYMARKET_PRIVATE_KEY"),
            chain_id=chain_id,
            signature_type=1,
            funder=os.getenv("POLYMARKET_FUNDER"),
        )

        creds = client.create_or_derive_api_creds()
        client.set_api_creds(creds)

        relayer_client = RelayClient(
            RELAYER_URL,
            chain_id,
            os.getenv("POLYMARKET_PRIVATE_KEY"),
            BuilderConfig(
                local_builder_creds=BuilderApiKeyCreds(
                    key=os.getenv("POLYMARKET_API_KEY"),
                    secret=os.getenv("POLYMARKET_API_SECRET"),
                    passphrase=os.getenv(
                        "POLYMARKET_API_PASSPHRASE"
                    ),
                )
            ),
        )

        service = PolyWeb3Service(
            clob_client=client,
            relayer_client=relayer_client,
        )

        logger.info(f"🔁 Redeeming condition {condition_ids}")
        return service.redeem(condition_ids=condition_ids)

    # =========================
    # 并发执行赎回
    # =========================
    async def execute_redeem(self):
        condition_ids = await self.get_redeemable_condition_ids()

        if not condition_ids:
            logger.info("没有可赎回的 condition")
            return
        try:
            result = self._redeem_on_chain_sync(condition_ids)
            print(result)
        except Exception as e:
            logger.info("赎回出错")

# =========================
# 入口
# =========================
settings = load_settings()
auto_redeem = AutoRedeem(settings)
asyncio.run(auto_redeem.execute_redeem())
